from django.shortcuts import render,redirect
from django.http import HttpResponse
from FileDoctor.settings import EMAIL_HOST_USER
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import EmailMessage
from django.utils.datastructures import MultiValueDictKeyError
from django.contrib.auth.models import User,auth
from django.contrib import messages
import random
from .models import mail,uploadfiles
from django.core.files.storage import FileSystemStorage
from .forms import uploadform
from zipfile import ZipFile
from zipfile import ZipFile
from itertools import permutations
import re
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import blue,red,black
from reportlab.lib.units import inch,cm
import fitz
from PyPDF2 import PdfFileMerger
from reportlab.platypus import Paragraph, Frame, KeepInFrame
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
from PyPDF2 import PdfFileMerger, PdfFileReader
from reportlab.lib.colors import PCMYKColor
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import VerticalBarChart
import os
from reportlab.platypus.tables import Table, TableStyle
from reportlab.lib import colors
from reportlab.graphics.charts.barcharts import HorizontalBarChart
from reportlab.graphics.shapes import Drawing
from FileDoct.models import percentage
# Create your views here.
usero=0
code=0
mail=''
s=""
def index(request):
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
def creators(request):
    return render(request,'creators.html')
def contact(request):
    return render(request,'contact.html')
def forget(request):
    return render(request,'forget.html',{'data':""})
def resetpassword(request):
    if request.method == 'POST':
        password1 = request.POST['password']
        password2 = request.POST['confirmpassword']
        if password1!=password2:
            return render(request,'resetpassword.html',{'data':"Both Passwords didn't match !"})
        else:
            user1=User.objects.get(email=mail)
            user1.set_password(password1)
            user1.save()
            return render(request,'join.html',{'uname':"",'pass':"",'data':""})
    return render(request,'resetpassword.html',{'data':""})
def verify(request):
    if request.method == 'POST':
        usercode = request.POST['code']
        print(usercode,code)
        if int(usercode)==int(code):
            return render(request,'resetpassword.html',{'data':""})
        else:
            return render(request,'verify.html',{'data':"The Entered code is invalid !",'mail':""})
def reset(request):
    if request.method == 'POST':
        email = request.POST['email']
        global mail
        mail=email
        user=User.objects.all()
        count = 0
        for use in user:
            if use.email==email:
                count=count+1
        if count==0:
            return render(request,'forget.html',{'data':"No such an email"})
        if count>0:
            user1=User.objects.get(email=email)
            firstname=user1.first_name
            lastname=user1.last_name
            global code
            code=random.randint(1111,9999)
            message="Hello "+firstname+" "+lastname+" ! Note : You will only one chance to enter Code. If you entered wrong the Code will Expire and you should take a new one after entering E-mail again. Your e-mail verification code is "+str(code)+" . Same is the case with your new password Selection if your new both passwords didn't match with each other your Code will again Expire and you should have a new one!!!!!"
            send_mail("Verification Code filedoctorz",message, EMAIL_HOST_USER, [email],fail_silently=False)
            return render(request,'verify.html',{'data':"",'mail':email})
    else:
        return render(request,'forget.html',{'data':""})
def doctor(request):
    if usero==1:
        return render(request,'doctor.html')
    else:
        return render(request,'join.html',{'uname':"",'pass':"",'data':""})
def logout(request):
    global usero
    usero=0
    auth.logout(request)
    return redirect('/')
def account(request):
    return render(request,'account.html')
def join(request):
    return render(request,'join.html',{'uname':"",'pass':"",'data':""})
def contactmail(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        try:
            message1 = request.POST['message']
        except MultiValueDictKeyError:
            message1 = ' '
        message = "My name is "+name+"."+" My e-Mail is "+email+"."+" "+message1
        send_mail(subject,message, EMAIL_HOST_USER, ['thefiledoctorz@gmail.com'],fail_silently=False)
        return render(request,'index.html')
    return render(request,'index.html')
def signup(request):
    if request.method == 'POST':
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirmpassword = request.POST['confirmpassword']
        message="Hello "+firstname+" "+lastname+" ! "+"Congratulations you have successfully joined TheFileDoctorz. For more info wisit our site. Thank you!"
        if password==confirmpassword:
            user=User.objects.all()
            count = 0
            for use in user:
                if use.username==username:
                    count=count+1
            if count>0:
                return render(request,'join.html',{'uname':"Username Already Taken !",'pass':"",'data':""})
            else:
                user=User.objects._create_user(username=username,email=email,password=password,first_name=firstname,last_name=lastname)
                send_mail("Successfully Joined!",message, EMAIL_HOST_USER, [email],fail_silently=False)
                user.save()
        else:
            return render(request,'join.html',{'uname':"",'pass':"Both passwords did not matched !",'data':""})
        return render(request,'join.html',{'uname':"",'pass':"",'data':""})
    else:
        return render(request,'join.html',{'uname':"",'pass':"",'data':""})
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            global usero
            usero=1
            return redirect('/')
        else:
            return render(request,'join.html',{'uname':"",'pass':"",'data':"Login credentials are wrong",})
    else:
        return render(request,'join.html',{'uname':"",'pass':"",'data':"",})
def changepassword(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['current_password']
        newpassword = request.POST['new_password']
        password1 = request.POST['confirm_password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            if newpassword==password1:
                user.set_password(newpassword)
                user.save()
            else:
                return render(request,'account.html',{'data':"Both New passwords didn't match with each other !"})
        else:
            return render(request,'account.html',{'data':"The Verification Credentials are Wrong !"})
    return render(request,'account.html',{'data':""})
def Reverse(tuples):
    new_tup = ()
    for k in reversed(tuples):
        new_tup = new_tup + (k,)
    return new_tup
def englishchecker(names):
    files=[]
    index=0
    combo1=[]
    combo=[]
    matched=[]
    percent_list=[]
    checked=[]
    all_data=[]
    final_words=[]
    final_words_count=[]
    hfiles=[]
    for c, x in enumerate(names):
        f = open ('/home/thefiledoctorz/FileDoctor/media/english/'+str(x),'r')
        files.append(f)
        index=index+1
    indextable=list(range(index))
    perm=permutations(indextable,2)
    for i in list(perm):
        combo1.append(i)
    for i in range(len(combo1)):
        for j in range(i):
            if Reverse(combo1[i])==combo1[j]:
                combo.append(Reverse(combo1[i]))
    for i in combo:
        matching=[]
        matching_count1=[]
        matching_count2=[]
        f3=[]
        f4=[]
        f1=files[i[0]].read()
        f2=files[i[1]].read()
        f33=f1.split('\n')
        f44=f2.split('\n')
        count=0
        for ii in f33:
            if ii=='':
                f33.pop(count)
            count=count+1
        count=0
        for ii in f44:
            if ii=='':
                f44.pop(count)
            count=count+1
        f5=''.join(f33)
        f6=''.join(f44)
        l1=f5.split('.')
        l2=f6.split('.')
        count=0
        for ii in l1:
            if ii=='':
                l1.pop(count)
            count=count+1
        count=0
        for ii in l2:
            if ii=='':
                l2.pop(count)
            count=count+1
        l3=''.join(l1)
        l4=''.join(l2)
        f3=l3.split(' ')
        f4=l4.split(' ')
        width=len(f33)
        height=len(f44)
        width=len(f3)/22
        height=len(f4)/22
        if len(f3)<30:
            width=3
        if len(f4)<30:
            height=3
        canvas=Canvas("/home/thefiledoctorz/FileDoctor/media/english/"+str(i[0])+str(i[1])+".pdf", pagesize=(8*inch,(width)+(height)*inch))
        frame=Frame(0.3*inch, 0.3*inch,7.4*inch,(((width)+(height))-0.6)*inch,showBoundary=1)
        bodyStyle = ParagraphStyle('Body', fontName="Helvetica", fontSize=12, leading=28, spaceBefore=6)
        bodyStyle1 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=16, leading=28, spaceBefore=6)
        bodyStyle11 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=16, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle2 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=12, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle3 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=10, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle4 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=16, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle5 = ParagraphStyle('Body', fontName="Helvetica", fontSize=12, leading=28, spaceBefore=50)
        bodyStyle6 = ParagraphStyle('Body', fontName="Helvetica", fontSize=12, leading=28, spaceBefore=10,alignment=TA_CENTER)
        if i[0] not in checked and i[1] not in checked:
            all_data.append(f3)
            all_data.append(f4)
            checked.append(i[0])
            checked.append(i[1])
        if i[0] not in checked:
            all_data.append(f3)
            checked.append(i[0])
        if i[1] not in checked:
            all_data.append(f4)
            checked.append(i[1])
        for p in f3:
            count=1
            if p.lower() in matching:
                ind=matching.index(p.lower())
                if ind>=0:
                    matching_count1[ind]=matching_count1[ind]+1
            else:
                for q in f4:
                    if p.lower()==q.lower():
                        if count==1:
                            matching.append(p.lower())
                            matching_count1.append(1)
                            matching_count2.append(1)
                            count=2
                        else:
                            ind=matching.index(p.lower())
                            if ind>=0:
                                matching_count2[ind]=matching_count2[ind]+1
        #print("Matching words in "+names[i[0]]+" and "+names[i[1]]+" is :",matching)
        #print("Matching words' count value in "+names[i[0]]+" is :",matching_count1)
        #print("Matching words' count value in "+names[i[1]]+" is :",matching_count2)
        total_words=len(f3)+len(f4)
        w1=sum(matching_count1)
        w2=sum(matching_count2)
        total_match_words=w1+w2
        percent=(total_match_words/total_words)*100
        matched.append(matching)
        percent_list.append(percent)
        #print("percentage of Matching words in "+names[i[0]]+" and "+names[i[1]]+" is :"+str(percent)+" %")
        para1=Paragraph("Comparison between two files :  ( "+names[i[0]]+" ) & ( "+names[i[1]]+" )\n",style=bodyStyle1)
        para2=Paragraph("Plagiarism: "+str(percent)+" % , Total words: "+str(total_words)+" & matched words: "+str(total_match_words),style=bodyStyle3)
        para3=Paragraph("-( "+names[i[0]]+" )-",bodyStyle2)
        para4=Paragraph(f1,style=bodyStyle)
        para5=Paragraph("-( "+names[i[1]]+" )-",bodyStyle2)
        para6=Paragraph(f2,style=bodyStyle)
        mydata=[para1,para2,para3,para4,para5,para6]
        frame.addFromList(mydata,canvas)
        canvas.save()
        doc = fitz.open("/home/thefiledoctorz/FileDoctor/media/english/"+str(i[0])+str(i[1])+".pdf")
        page = doc[0]
        for jp in matching:
            text = " "+jp+" "
            text_instances = page.searchFor(text)
            ### HIGHLIGHT
            for inst in text_instances:
                highlight = page.addHighlightAnnot(inst)
            ### OUTPUT
        doc.save("/home/thefiledoctorz/FileDoctor/media/english/"+str(i[0])+str(i[1])+"h.pdf", garbage=4, deflate=True, clean=True)
        hfiles.append("/home/thefiledoctorz/FileDoctor/media/english/"+str(i[0])+str(i[1])+"h.pdf")
        files[i[0]].seek(0)
        files[i[1]].seek(0)
    stat=0
    pstat=1
    for it in matched[0]:
        for ids in range(1,len(matched)):
            if it in matched[ids]:
                stat=1
            else:
                stat=0
        if stat==1:
            final_words.append(it)
    for i in final_words:
        words_count=0
        for j in all_data:
            words_count=words_count+j.count(i)
        final_words_count.append(words_count)
    le=0
    final_count=0
    for i in all_data:
        le=le+len(i)
    if len(matched)==1:
        final_words=matched[0]
        for i in final_words:
            words_count=0
            for j in all_data:
                words_count=words_count+j.count(i)
            final_words_count.append(words_count)
    final_count=sum(final_words_count)
    final_percent=(final_count/le)*100
    #print("All Common words in all files :",final_words)
    #print("Count value of above words",final_words_count)
    #print("Total percentage :"+str(final_percent)+" %")
    d = Drawing(4*inch,2*inch)
    bar = HorizontalBarChart()
    bar.x = 1*inch
    bar.y = 0.4*inch
    data1 = []
    o=[]
    o.append(final_percent)
    o.append(100-final_percent)
    data1.append(o)
    bar.data = data1
    bar.valueAxis.valueMin = 0
    bar.valueAxis.valueMax = 100
    bar.valueAxis.valueStep = 10
    bar.categoryAxis.labels.boxAnchor = 'ne'
    bar.categoryAxis.labels.dx = -5
    bar.categoryAxis.labels.fontName = 'Helvetica'
    bar.categoryAxis.categoryNames = ['Plagiarized', 'Uniqueness']
    bar.bars[(0, 0)].fillColor = colors.red
    bar.bars[(0, 1)].fillColor = colors.green
    d.add(bar, '')
    d.save(formats=['jpg'], outDir='.', fnRoot='/home/thefiledoctorz/FileDoctor/media/english/chart')
    canvas=Canvas("/home/thefiledoctorz/FileDoctor/media/english/0.pdf",pagesize=(8*inch,(6*inch)+(len(final_words)*1*cm)+3*inch))
    frame=Frame(0.3*inch, 0.3*inch,7.4*inch,(len(final_words)*1*cm)+4.8*inch)
    coverpic="/home/thefiledoctorz/FileDoctor/media/2.png"
    logo="/home/thefiledoctorz/FileDoctor/media/1.jpg"
    chart="/home/thefiledoctorz/FileDoctor/media/english/chart.jpg"
    styles = getSampleStyleSheet()
    styleN = styles["BodyText"]
    styleN.alignment = TA_LEFT
    styleBH = styles["Normal"]
    styleBH.alignment = TA_CENTER
    canvas.drawBoundary(2,0.3*inch,0.3*inch,7.4*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch)
    canvas.drawImage(coverpic,0.4*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch-3.3*inch,width=7.2*inch,height=3.5*inch,mask='auto')
    canvas.drawImage(logo,2.2*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch-3.9*inch,width=0.5*inch,height=0.5*inch,mask='auto')
    canvas.drawImage(chart,3.5*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch-8*inch,width=4*inch,height=2*inch,mask='auto')
    para1=Paragraph("The File Doctorz",bodyStyle4)
    para2=Paragraph("Creators's Name : Faizan Ali and Sohaib-Bin-Maqsood",bodyStyle5)
    para3=Paragraph("Our e-Mail : thefiledoctorz@gmail.com",bodyStyle)
    para4=Paragraph("Plagiarism Report",bodyStyle11)
    para5=Paragraph("Total Plagiarism calculated: "+str(final_percent)+" % , Total words in all files : "+str(le)+", matched words among all files: "+str(len(final_words))+" & theses words occur total "+str(final_count)+" times.\n",style=bodyStyle3)
    para6=Paragraph("Further Details : ",bodyStyle1)
    mydata=[para1,para2,para3,para4,para5,para6]
    frame.addFromList(mydata,canvas)
    data = []
    # Headers
    h1 = Paragraph('''<b>Matched Words</b>''', styleBH)
    h2 = Paragraph('''<b>Count Value</b>''', styleBH)
    d1=[h1,h2]
    data.append(d1)
    for i in range(len(final_words)):
        a=[]
        v1 = Paragraph(final_words[i], styleN)
        v2 = Paragraph(str(final_words_count[i]), styleN)
        a.append(v1)
        a.append(v2)
        data.append(a)
    table = Table(data, colWidths=[2.05 * cm, 2.7 * cm, 5 * cm,
                               3* cm, 3 * cm])
    table.setStyle(TableStyle([
                       ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                       ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                       ]))
    width = 400
    height = 100
    x = 1*inch
    y = 1*inch
    table.wrapOn(canvas, width, height)
    table.drawOn(canvas, x, y)
    canvas.save()
    hfiles.append("/home/thefiledoctorz/FileDoctor/media/english/0.pdf")
    merger = PdfFileMerger()
    files = hfiles
    for fname in sorted(files):
        merger.append(PdfFileReader(open(fname, 'rb')))
    merger.write("/home/thefiledoctorz/FileDoctor/media/english/PlagiarismReport.pdf")
    return final_percent


def LCS(X,Y):
    m=len(X)
    n=len(Y)
    c=[[0 for i in range(m+1)] for j in range(n+1)]
    b=[[0 for i in range(m+1)] for j in range(n+1)]
    if X[0].lower()==Y[0].lower():
        if m==0 or n==0:
            return
        for i in range(1,n+1):
            for j in range(1,m+1):
                if Y[i-1].upper()==X[j-1].upper():
                    c[i][j]=1+c[i-1][j-1]
                    b[i][j]="D"
                else:
                    c[i][j]=max(c[i-1][j],c[i][j-1])
                    if c[i-1][j]>c[i][j-1]:
                        b[i][j]="U"
                    else:
                        b[i][j]="L"
    return b,c
def Print_LCS(b, X, i, j):
    if i == 0 or j == 0:
        return
    if b[i][j] == "D":
        global s
        s=X[j-1]+s
        Print_LCS(b, X, i-1, j-1)
    elif b[i][j] == "U":
        Print_LCS(b, X, i-1, j)
    elif b[i][j] == "L":
        Print_LCS(b, X, i, j-1)
def checker(X,Y):
    global s
    s=""
    if len(X)>len(Y):
        t=(len(X)*90)/100
    else:
        t=(len(Y)*90)/100
    if X==Y:
       return X
    else:
        b,c=LCS(X,Y)
        Print_LCS(b,X,len(Y),len(X))
        if s != "" and len(s)>t:
            return s


def cppchecker(names):
    files=[]
    index=0
    combo1=[]
    combo=[]
    checked=[]
    all_data=[]
    matched=[]
    matched_count=[]
    final_words=[]
    final_words_count=[]
    tolerate=2
    hfiles=[]
    for count, x in enumerate(names):
        f = open ('/home/thefiledoctorz/FileDoctor/media/cpp/'+str(x),'r')
        files.append(f)
        index=index+1
    indextable=list(range(index))
    perm=permutations(indextable,2)
    for i in list(perm):
        combo1.append(i)
    for i in range(len(combo1)):
        for j in range(i):
            if Reverse(combo1[i])==combo1[j]:
                combo.append(Reverse(combo1[i]))
    for i in combo:
        f5=[]
        f6=[]
        matching=[]
        matching_count1=[]
        matching_count2=[]
        f1=files[i[0]].read()
        f2=files[i[1]].read()
        f3=f1.split('\n')
        f4=f2.split('\n')
        for ii in f3:
            k=ii.strip()
            ki=' '.join(k.split())
            if not ki.startswith("//"):
                if not ki.startswith("{"):
                    if not ki.startswith("}"):
                        if not ki == '':
                            f5.append(ki)
        for ii in f4:
            k=ii.strip()
            ki=' '.join(k.split())
            if not ki.startswith("//"):
                if not ki.startswith("{"):
                    if not ki.startswith("}"):
                        if not ki == '':
                            f6.append(ki)
        if i[0] not in checked and i[1] not in checked:
            all_data.append(f5)
            all_data.append(f6)
            checked.append(i[0])
            checked.append(i[1])
        if i[0] not in checked:
            all_data.append(f5)
            checked.append(i[0])
        if i[1] not in checked:
            all_data.append(f6)
            checked.append(i[1])
        line=((len(f5)*0.3)+(len(f6)*0.3))-1.7
        canvas=Canvas("/home/thefiledoctorz/FileDoctor/media/cpp/"+str(i[0])+str(i[1])+".pdf", pagesize=(8*inch,((len(f5)*0.3)+(len(f6)*0.3))*inch))
        frame=Frame(0.3*inch, 0.3*inch,7.4*inch,(((len(f5)*0.3)+(len(f6)*0.3))-0.6)*inch,showBoundary=1)
        bodyStyle = ParagraphStyle('Body', fontName="Helvetica", fontSize=12, leading=28, spaceBefore=6)
        bodyStyle1 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=16, leading=28, spaceBefore=6)
        bodyStyle11 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=16, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle2 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=12, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle3 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=10, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle4 = ParagraphStyle('Body', fontName="Helvetica-bold", fontSize=16, leading=28, spaceBefore=6,alignment=TA_CENTER)
        bodyStyle5 = ParagraphStyle('Body', fontName="Helvetica", fontSize=12, leading=28, spaceBefore=50)
        bodyStyle6 = ParagraphStyle('Body', fontName="Helvetica", fontSize=12, leading=28, spaceBefore=10,alignment=TA_CENTER)
        for p in range(len(f5)):
            if p in matching:
                ind=matching.index(p)
                matching_count2[ind]=matching_count2[ind]+1
            for q in range(p-tolerate,p+tolerate):
                if not q < 0 and not q >= len(f6):
                    value=checker(f5[p],f6[q])
                    if value != None:
                        if value not in matching:
                            matching.append(value)
                            matching_count1.append(1)
                            matching_count2.append(1)
                        else:
                            ind=matching.index(value)
                            matching_count1[ind]=matching_count1[ind]+1
        total_words=len(f5)+len(f6)
        w1=sum(matching_count1)
        w2=sum(matching_count2)
        total_match_words=w1+w2
        percent=(total_match_words/total_words)*100
        matched.append(matching)
        para1=Paragraph("Comparison between two files :  ( "+names[i[0]]+" ) & ( "+names[i[1]]+" )\n",style=bodyStyle1)
        para2=Paragraph("Plagiarism: "+str(percent)+" % , Total lines: "+str(total_words)+" & matched lines: "+str(total_match_words),style=bodyStyle3)
        para3=Paragraph("-( "+names[i[0]]+" )-",bodyStyle2)
        mydata=[para1,para2,para3]
        frame.addFromList(mydata,canvas)
        for ii in f5:
            canvas.drawString(0.5*inch,line*inch,ii)
            line=line-0.2
        canvas.drawString(3*inch,line*inch,"-( "+names[i[1]]+" )-")
        line=line-0.5
        line=line-0.3
        for ii in f6:
            canvas.drawString(0.5*inch,line*inch,ii)
            line=line-0.2
        canvas.save()
        doc = fitz.open("/home/thefiledoctorz/FileDoctor/media/cpp/"+str(i[0])+str(i[1])+".pdf")
        page = doc[0]
        for jp in matching:
            tru=1
            text = jp
            text_instances = page.searchFor(text)
            ### HIGHLIGHT
            for inst in text_instances:
                highlight = page.addHighlightAnnot(inst)
            ### OUTPUT
        doc.save("/home/thefiledoctorz/FileDoctor/media/cpp/"+str(i[0])+str(i[1])+"h.pdf", garbage=4, deflate=True, clean=True)
        hfiles.append("/home/thefiledoctorz/FileDoctor/media/cpp/"+str(i[0])+str(i[1])+"h.pdf")
        files[i[0]].seek(0)
        files[i[1]].seek(0)
    stat=0
    for it in matched[0]:
        for ids in range(1,len(matched)):
            if it in matched[ids]:
                stat=1
            else:
                stat=0
        if stat==1:
            final_words.append(it)
    for i in final_words:
        words_count=0
        for j in all_data:
            words_count=words_count+j.count(i)
        final_words_count.append(words_count)
    le=0
    final_count=0
    for i in all_data:
        le=le+len(i)
    if len(matched)==1:
        final_words=matched[0]
        for i in final_words:
            words_count=0
            for j in all_data:
                words_count=words_count+j.count(i)
            final_words_count.append(words_count)
    final_count=sum(final_words_count)
    final_percent=(final_count/le)*100
    d = Drawing(4*inch,2*inch)
    bar = HorizontalBarChart()
    bar.x = 1*inch
    bar.y = 0.4*inch
    data1 = []
    o=[]
    o.append(final_percent)
    o.append(100-final_percent)
    data1.append(o)
    bar.data = data1
    bar.valueAxis.valueMin = 0
    bar.valueAxis.valueMax = 100
    bar.valueAxis.valueStep = 10
    bar.categoryAxis.labels.boxAnchor = 'ne'
    bar.categoryAxis.labels.dx = -5
    bar.categoryAxis.labels.fontName = 'Helvetica'
    bar.categoryAxis.categoryNames = ['Plagiarized', 'Uniqueness']
    bar.bars[(0, 0)].fillColor = colors.red
    bar.bars[(0, 1)].fillColor = colors.green
    d.add(bar, '')
    d.save(formats=['jpg'], outDir='.', fnRoot='/home/thefiledoctorz/FileDoctor/media/cpp/chart')
    canvas=Canvas("/home/thefiledoctorz/FileDoctor/media/cpp/0.pdf",pagesize=(8*inch,(6*inch)+(len(final_words)*1*cm)+3*inch))
    frame=Frame(0.3*inch, 0.3*inch,7.4*inch,(len(final_words)*1*cm)+4.8*inch)
    coverpic="/home/thefiledoctorz/FileDoctor/media/2.png"
    logo="/home/thefiledoctorz/FileDoctor/media/1.jpg"
    chart="/home/thefiledoctorz/FileDoctor/media/cpp/chart.jpg"
    styles = getSampleStyleSheet()
    styleN = styles["BodyText"]
    styleN.alignment = TA_LEFT
    styleBH = styles["Normal"]
    styleBH.alignment = TA_CENTER
    canvas.drawBoundary(2,0.3*inch,0.3*inch,7.4*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch)
    canvas.drawImage(coverpic,0.4*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch-3.3*inch,width=7.2*inch,height=3.5*inch,mask='auto')
    canvas.drawImage(logo,2.2*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch-4.1*inch,width=0.5*inch,height=0.5*inch,mask='auto')
    canvas.drawImage(chart,3.5*inch,6*inch+len(final_words)*1*cm+3*inch-0.6*inch-8.6*inch,width=4*inch,height=2*inch,mask='auto')
    para1=Paragraph("The File Doctorz",bodyStyle4)
    para2=Paragraph("Creators's Name : Faizan Ali and Sohaib-Bin-Maqsood",bodyStyle5)
    para3=Paragraph("Our e-Mail : thefiledoctorz@gmail.com",bodyStyle)
    para4=Paragraph("Plagiarism Report",bodyStyle11)
    para5=Paragraph("Total Plagiarism calculated: "+str(final_percent)+" % , Total lines in all files : "+str(le)+", matched lines among all files: "+str(len(final_words))+" & theses lines occur total "+str(final_count)+" times.\n",style=bodyStyle3)
    para6=Paragraph("Further Details : ",bodyStyle1)
    mydata=[para1,para2,para3,para4,para5,para6]
    frame.addFromList(mydata,canvas)
    data = []
    # Headers
    h1 = Paragraph('''<b>Matched Words</b>''', styleBH)
    h2 = Paragraph('''<b>Count Value</b>''', styleBH)
    d1=[h1,h2]
    data.append(d1)
    for i in range(len(final_words)):
        a=[]
        v1 = Paragraph(final_words[i], styleN)
        v2 = Paragraph(str(final_words_count[i]), styleN)
        a.append(v1)
        a.append(v2)
        data.append(a)
    table = Table(data, colWidths=[2.05 * cm, 2.7 * cm, 5 * cm,
                               3* cm, 3 * cm])
    table.setStyle(TableStyle([
                       ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                       ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                       ]))
    width = 400
    height = 100
    x = 1*inch
    y = 1*inch
    table.wrapOn(canvas, width, height)
    table.drawOn(canvas, x, y)
    canvas.save()
    hfiles.append("/home/thefiledoctorz/FileDoctor/media/cpp/0.pdf")
    merger = PdfFileMerger()
    files = hfiles
    for fname in sorted(files):
        merger.append(PdfFileReader(open(fname, 'rb')))
    merger.write("/home/thefiledoctorz/FileDoctor/media/cpp/PlagiarismReport.pdf")
    return final_percent

def upload(request):
    if request.method=='POST':
        fileuploaded=request.FILES['document']
        checker=request.POST['checker']
        uploading=uploadfiles()
        per=percentage()
        uploading.checker=checker
        uploading.file=fileuploaded
        uploading.save()
        #fs=FileSystemStorage()
        #fs.save(fileuploaded.name,fileuploaded)
        with ZipFile(fileuploaded,'r') as zipObj:
            zipObj.extractall('/home/thefiledoctorz/FileDoctor/media/'+checker+'/')
            names=zipObj.namelist()
        if checker=='english':
            p=englishchecker(names)
        else:
            p=cppchecker(names)
        per.checker=checker
        per.file=fileuploaded
        per.percent=p
        per.save()
    return render(request,'download.html',{'file':"/media/"+checker+"/PlagiarismReport.pdf",'p':int(p),'u':int(100-p)})