from django.db import models

# Create your models here.
class mail(models.Model):
    mail=models.EmailField()
    code=models.IntegerField()
class uploadfiles(models.Model):
    file=models.FileField(upload_to='zip')
    checker=models.CharField(max_length=100)
    def __str__(self):
        return self.checker
class percentage(models.Model):
    file=models.FileField(upload_to='zip')
    checker=models.CharField(max_length=100)
    percent=models.CharField(max_length=100)
    def __str__(self):
        return self.checker