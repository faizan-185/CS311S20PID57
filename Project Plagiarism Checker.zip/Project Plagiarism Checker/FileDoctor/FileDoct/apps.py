from django.apps import AppConfig


class FiledoctConfig(AppConfig):
    name = 'FileDoct'
