from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name="index"),
    path('index.html',views.index,name="index"),
    path('about.html',views.about,name="about"),
    path('creators.html',views.creators,name="creators"),
    path('contact.html',views.contact,name="contact"),
    path('doctor.html',views.doctor,name="doctor"),
    path('join.html',views.join,name="join"),
    path('mail',views.contactmail,name="mail"),
    path('login',views.login,name="login"),
    path('signup',views.signup,name="signup"),
    path('account.html',views.account,name="account"),
    path('forget',views.forget,name="forget"),
    path('reset',views.reset,name="reset"),
    path('resetpassword',views.resetpassword,name="resetpassword"),
    path('verify',views.verify,name="verify"),
    path('logout',views.logout,name="logout"),
    path('changepassword',views.changepassword,name="changepassword"),
    path('upload',views.upload,name="upload"),
]