from django import forms
from .models import uploadfiles
class uploadform(forms.ModelForm):
    class Meta:
        model=uploadfiles
        fields=('file','checker')