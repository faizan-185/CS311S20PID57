#include <iostream>
using namespace std;
struct Activity
{
    int start, finish;
};
bool Activity_Select(Activity a1, Activity a2)
{
    return (a1.finish <= a2.start);
}
int main()
{
    Activity activities[]={{1, 4},{3, 5},{0, 6},{5, 7},{3, 8},{5, 9},{6, 10},{8, 11},{8, 12},{2, 13},{12, 14}};
    Activity selected_activities[sizeof(activities)/sizeof(activities[0])]{};
    int n = sizeof(activities)/sizeof(activities[0]);
    int t=1;
    selected_activities[0].start=activities[0].start;
    selected_activities[0].finish=activities[0].finish;
    for(int i=1;i<n;i++)
    {
        if(Activity_Select(selected_activities[t-1],activities[i]))
        {
            selected_activities[t].start=activities[i].start;
            selected_activities[t].finish=activities[i].finish;
            t++;
        }
    }
    cout << "Given Activities with start and finish time : \n";
    for (int i=0; i<n; i++)
       cout << "[" << activities[i].start << "," <<activities[i].finish
            << "] ";
    cout << "\nSelected Activities : \n";
    for (int i=0; i<t; i++)
       cout << "[" << selected_activities[i].start << "," << selected_activities[i].finish
            << "] ";
    return 0;
}