#include <iostream>
using namespace std;
int arr[200]{};
void Activities(int arr[],int acts[][2])
{
    for(int i=0;i<11;i++)
    {
        for(int j=0;j<i;j++)
        {
            if (acts[j][1] < acts[i][0] && arr[i] < arr[j])
    			arr[i] = arr[j];
        }
        arr[i]=arr[i]+1;
    }
    if(acts[0][1]>acts[1][0])
        arr[0]=0;
}
int main()
{
    int act[11][2]={{0, 6}, {1, 4}, {2, 13}, {3, 5}, {3, 8}, {5, 7}, {5, 9}, {6, 10}, {8, 11}, {8, 12}, {12, 14}};
    Activities(arr,act);
    cout<<"The Maximum Number of Activities : "<<arr[11]<<endl;
    cout<<"The Maximum Activities : \n";
    int l=0;
    int in=0;
    for(int i=0;i<11;i++)
    {
        if(arr[i]!=l)
        {
            cout<<act[i][0]<<", "<<act[i][1]<<endl;
            l=arr[i];
        }
        in++;
    }
}